/* eslint-env vitest */
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../../features/auth/authSlice";
import LoginPage from "../../pages/LoginPage";

describe("LoginPage Component", () => {
  const renderWithStore = (ui, { preloadedState, store = configureStore({ reducer: { auth: authReducer }, preloadedState }) } = {}) => {
    return render(<Provider store={store}><MemoryRouter>{ui}</MemoryRouter></Provider>);
  };

  it("renders login form elements correctly", () => {
    renderWithStore(<LoginPage />);

    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /login/i })).toBeInTheDocument();
  });

  it("calls login handler when form submitted", () => {
    const store = configureStore({ reducer: { auth: authReducer } });
    render(
      <Provider store={store}>
        <MemoryRouter>
          <LoginPage />
        </MemoryRouter>
      </Provider>
    );

    fireEvent.change(screen.getByLabelText(/email/i), { target: { value: "admin12345@gmail.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "admin12345" } });
    fireEvent.click(screen.getByRole("button", { name: /login/i }));

    expect(screen.getByRole("button", { name: /login/i })).toBeInTheDocument();
  });
});
