import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { createThread } from '../features/threads/threadsSlice';

export default function CreateThread() {
  const dispatch = useDispatch();
  const { isLoading } = useSelector((state) => state.threads);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [body, setBody] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(createThread({ title, body, category }));
    setTitle('');
    setCategory('');
    setBody('');
  };

  return (
    <div className="div-auth">
      <form
        onSubmit={handleSubmit}
        className="border p-4 mb-4 rounded thread-create-form"
      >
        <h2 className="text-xl font-semibold mb-2">Create Thread</h2>
        <input
          className="border p-2 w-full mb-2"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <input
          className="border p-2 w-full mb-2"
          placeholder="Category (optional)"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        />
        <textarea
          className="border p-2 w-full mb-2"
          placeholder="Body"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          required
        />
        <button type="submit" className="btn-primary" disabled={isLoading}>
          {isLoading ? 'Posting...' : 'Post Thread'}
        </button>

        {/* Floating Button */}
        {/* <button
        type="button"
        className="floating-btn"
        onClick={() => navigate('/create')}
      >
        <FontAwesomeIcon icon={faPlus} />
      </button> */}
      </form>
    </div>
  );
}
